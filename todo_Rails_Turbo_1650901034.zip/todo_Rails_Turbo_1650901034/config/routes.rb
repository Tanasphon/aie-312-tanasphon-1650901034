Rails.application.routes.draw do
  resources :categories do
    resources :tasks, only: [:index, :new, :create]
  end

  resources :tasks, only: [:index, :create, :edit, :update, :destroy] do
    member do
      patch :complete
    end
  end

  root "tasks#index"
end
