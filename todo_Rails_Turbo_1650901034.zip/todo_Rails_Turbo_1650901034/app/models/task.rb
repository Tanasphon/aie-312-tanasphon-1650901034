class Task < ApplicationRecord
  # สมมติว่าใช้ status ในการเก็บสถานะของ task
  scope :incomplete, -> { where(status: :incomplete) }
  scope :complete, -> { where(status: :complete) }
end
