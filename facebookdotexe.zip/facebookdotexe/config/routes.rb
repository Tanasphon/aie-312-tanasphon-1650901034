Rails.application.routes.draw do
  devise_for :users

  # Main root route for the application
  root "posts#index"

  # Routes for posts
  resources :posts do
    member do
      post 'like'  # เส้นทางสำหรับการกดไลค์โพสต์
      delete 'unlike'  # เส้นทางสำหรับการลบไลค์โพสต์
    end
    resources :comments, only: [:create, :destroy]
  end

  # Health check route
  get "up" => "rails/health#show", as: :rails_health_check

  # Route for deleting a post (outside of resources block)
  get '/posts/:id/delete', to: 'posts#destroy', as: :delete_post
end
