class Post < ApplicationRecord
  belongs_to :user
  has_many :likes, dependent: :destroy
  has_many :comments, dependent: :destroy

  # ตรวจสอบว่าผู้ใช้เคยกดไลค์โพสต์นี้หรือไม่
  def liked_by?(user)
    likes.exists?(user_id: user.id)
  end
end
